USE market_star_schema;
CREATE TABLE `employee` (
    `Emp_id` VARCHAR(12) NOT NULL,
    `Emp_Name` VARCHAR(25) DEFAULT NULL,
    `Des` VARCHAR(12) DEFAULT NULL,
    `Salary` int8 
    );
INSERT INTO `employee` VALUES ('1','Aman','E',2000),('2','Nitin','M-Aman',3000),('3','Harshit','E',3000),('4','Gaurav','M-Harshit',2000),('5','Dhurv','E',6000),('6','Hemant','M-Dhruv',5000);

select * from `employee`;
with cte1 as 
(
select * from employee
),
cte2 as 
(
SELECT *,
	   SUBSTRING(`des`, 3, 25) AS downline_emp
FROM `employee`
WHERE `des` != 'E'
)
select cte1.Emp_id,cte1.Emp_Name,cte1.Salary,cte2.Salary from
cte1 
left join 
cte2 on cte1.Emp_Name=cte2.downline_emp
where
cte1.Salary>cte2.Salary
;

SELECT 
    e1.Emp_id AS Employee_ID,
    e1.Emp_Name AS Employee_Name,
    e1.Salary as Employee_Salary,
    e2.Salary as Upline_Salary,
    e2.Emp_id AS Upline_ID,
    e2.Emp_Name AS Upline_Name
FROM employee e1
LEFT JOIN employee e2 
    ON e1.des LIKE CONCAT('%', e2.Emp_Name)
WHERE e1.des != 'E'
AND
e1.Salary>e2.Salary;


/*
❓Problem Statement:
Find the name of employees whose salary is greater 
than the salary of their manager and who joined 
before their manager. 
Also show their manager's name, salaries, and join dates.
*/

DROP table employees;
CREATE TABLE employees (
    emp_id INT PRIMARY KEY,
    name VARCHAR(50),
    designation VARCHAR(50),
    salary INT,
    manager_id INT,
    join_date DATE,
    FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
);

INSERT INTO employees (emp_id, name, designation, salary, manager_id, join_date) VALUES
(1, 'Alice', 'CEO', 300000, NULL, '2020-10-01'),
(2, 'Bob', 'CTO', 400000, 1, '2020-03-10'),
(3, 'Charlie', 'CFO', 190000, 1, '2020-05-15'),
(4, 'David', 'Lead Dev', 150000, 2, '2021-01-01'),
(5, 'Eva', 'Dev', 100000, 4, '2021-06-01'),
(6, 'Frank', 'Dev', 105000, 4, '2022-01-10'),
(7, 'Grace', 'Accountant', 95000, 3, '2021-05-15'),
(8, 'Heidi', 'Intern', 40000, 5, '2023-07-01');

select 
e1.name as Employee_Name,
e1.join_date as Employee_Join,
e1.Salary as Employee_Salary,
e2.name as Manager_Name,
e2.Salary as Manager_Salary,
e2.join_date as Manager_Join
from employees e1 
left join employees e2
on e1.manager_id =e2.emp_id
where e1.Salary>e2.Salary 
and e1.join_date<e2.join_date;
