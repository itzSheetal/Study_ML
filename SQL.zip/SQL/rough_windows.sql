create database mlc76;
use mlc76;

drop  table a1;
-- Create the table a1
CREATE TABLE a1 (
    Name VARCHAR(50)
);

-- Insert data into the table a1
INSERT INTO a1 (Name) VALUES
('Aus'),
('Aus'),
('Ind'),
('Ind'),
('UK');


select * from a1;


-- 
select *, 
row_number() over (order by name) as rnum,
rank() over (order by name) as r_ank,
dense_rank() over (order by name) as dr_ank
from a1;
-- with partition by
select *, 
row_number() over (partition by name order by name) as rnum,
rank() over (partition by name order by name) as r_ank,
dense_rank() over (partition by name order by name) as dr_ank
from a1;
--



-- Create the table A2
CREATE TABLE A2 (
    Name VARCHAR(50),
    Age INT
);

-- Insert data into the table A2
INSERT INTO A2 (Name, Age) VALUES
('a', 20),
('b', 21),
('c', 22),
('d', 23),
('e', 24);

select * from A2;



--
select *,
sum(age) over (order by name) as r_sum,
avg(age) over (order by name) as r_avg
from a2;
--
select *,
lead(age) over (order by name) as leadage,
lag(age) over (order by name) as lagage
from a2;
--



-- Create the table A3
CREATE TABLE A3 (
    Name VARCHAR(50),
    Age INT
);

-- Insert data into the table A2
INSERT INTO A3 (Name, Age) VALUES
('a', 20),
('a', 21),
('c', 22),
('c', 23),
('e', 24);

select * from A3;
-- -- -- -- -- -- -- -- -- -- 

-- partition by with lead, lag
select *,
lead(age) over (partition by name order by name) as lead_age,
lag(age) over (partition by name order by name) as lag_age
from a3;
--
select *,
sum(age) over (partition by name order by name ROWS UNBOUNDED PRECEDING) as sum_age,
avg(age) over (partition by name order by name ROWS UNBOUNDED PRECEDING)  as avg_age
from a3;
--



CREATE TABLE Employee (
    		Dept VARCHAR(20),
    		ID INT PRIMARY KEY,
    		Salary INT
);
 
INSERT INTO Employee (Dept, ID, Salary) VALUES
('HR', 1, 901),
('HR', 2, 296),
('HR', 3, 221),
('HR', 4, 519),
('IT', 5, 972),
('IT', 6, 852),
('IT', 7, 365),
('IT', 8, 213),
('Analytics', 9, 135),
('Analytics', 10, 799),
('Analytics', 11, 337),
('Analytics', 12, 855),
('Finance', 13, 390),
('Finance', 14, 110),
('Finance', 15, 377),
('Finance', 16, 847);
 
 
select * from Employee;
 

-- i. Find top 2 salaries for each dept?
-- ii. Find minimum salary for each dept?


-- Question 2 :
CREATE TABLE subscriptions (
    month INT,          -- Use 1 for Jan, 2 for Feb, ..., 6 for Jun, 7 for Jul
    subscribers INT
);

INSERT INTO subscriptions (month, subscribers) VALUES
(1, 1000),
(2, 1100),
(3, 950),
(4, 1200),
(5, 1500),
(6, 1800),
(7, 1600);

select * from subscriptions;

-- Calculate Month on Month % change in the subscriptions

with cte1 as (
select *, lag(subscribers) over(order by month) as lead_subs
from subscriptions
)
select *, 100*((lead_subs-subscribers)/lead_subs) from cte1;

-- Question 3 : 

CREATE TABLE sub (
    month INT,
    platform VARCHAR(10),
    subscribers INT
);

INSERT INTO sub (month, platform, subscribers) VALUES
(1, 'Android', 1000),
(2, 'Android', 1100),
(3, 'Android', 950),
(4, 'Android', 1200),
(5, 'Android', 1500),
(6, 'Android', 1800),
(7, 'Android', 1600),
(1, 'iOS', 800),
(2, 'iOS', 900),
(3, 'iOS', 870),
(4, 'iOS', 950),
(5, 'iOS', 970),
(6, 'iOS', 1000),
(7, 'iOS', 1100);

select * from sub;
-- Calculate Month on Month % change in the subscriptions for each platform!


with cte2 as (
select *, lag(subscribers) over(partition by platform order by month) as lag_subs
from sub
)
select *, 100*((lag_subs-subscribers)/lag_subs) from cte2;